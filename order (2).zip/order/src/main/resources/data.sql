insert into order
values(10001,'20/12/2019', 'Upanand','bengaluru',4);