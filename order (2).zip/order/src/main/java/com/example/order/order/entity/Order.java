package com.example.order.order.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;


@Entity
public class Order {
	
	@Id
	@GeneratedValue
	private  Long orderId;
	
	private String customerName;
	private String orderDate;
	private String shippingAddress;
	private int orderItems;
	//private double totalCost;
	
	public Order() {};
	
	public Order(Long orderId, String customerName, String orderDate, String shippingAddress, int orderItems) {
		super();
		this.orderId = orderId;
		this.customerName = customerName;
		this.orderDate = orderDate;
		this.shippingAddress = shippingAddress;
		this.orderItems = orderItems;
		//this.totalCost = totalCost;
	}


	public Long getOrderId() {
		return orderId;
	}

	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(String orderDate) {
		this.orderDate = orderDate;
	}

	public String getShippingAddress() {
		return shippingAddress;
	}

	public void setShippingAddress(String shippingAddress) {
		this.shippingAddress = shippingAddress;
	}

	public int getOrderItems() {
		return orderItems;
	}

	public void setOrderItems(int orderItems) {
		this.orderItems = orderItems;
	}

	/*public double getTotalCost() {
		return totalCost;
	}

	public void setTotalCost(double totalCost) {
		this.totalCost = totalCost;
	}*/
	

}
