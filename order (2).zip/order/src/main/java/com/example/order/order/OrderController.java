package com.example.order.order;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.order.order.entity.Order;
import com.example.order.order.repository.OrderRepository;

@RestController
public class OrderController {
	
	OrderRepository orderepository; 
	
	@PostMapping("/order")
	Order createOrder(@RequestBody Order newOrder) {
		return orderepository.save(newOrder);
	}

}
